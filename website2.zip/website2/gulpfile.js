function defaultTask(cb) {
  console.log("wassup");
  cb();
}

exports.default = defaultTask