const swiper = null;

function initSwiperOnMobile() {
    const element = document.querySelector(".course-swiper");
    if (!element) return;

    function checkScreenSize() {
        if (window.innerWidth < 850) {
            if (!element.classList.contains('swiper-initialized')) {
                element.classList.add('swiper');

                let slidesPerView = 1;
                if (window.innerWidth >= 600 && window.innerWidth < 850) {
                    slidesPerView = 2;
                } else if (window.innerWidth < 600) {
                    slidesPerView = 1;
                } else if (window.innerWidth > 800) {
                    slidesPerView = 3;
                }

                swiper = new Swiper('.course-swiper',
                    {
                        pagination: {
                            el: '.swiper-pagination',
                            clickable: true,
                        },
                        direction: 'horizontal',
                        centeredSlides: false,
                        loop: false,
                        clickable: true,
                        initialSlide: 0,
                        slidesPerView: slidesPerView,
                        autoHeight: true,
                        breakpoints: {
                            0: {
                                slidesPerView: 1,
                                spaceBetween: 10
                            },

                            600: {
                                slidesPerView: 2,
                                spaceBetween: 20
                            },
                        },
                        on: {
                            init: function () {
                                element.classList.add('swiper-initialized')
                            }
                        }
                    });
            } else {
                element.classList.remove("swiper");
                element.classList.remove('swiper-initialized');

                if (swiper != null) {
                    swiper.destroy(true, true);
                    swiper = null;
                }
            }
        }
    }

    checkScreenSize();

    let resizeTimeout;
    window.addEventListener('resize', function () {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(checkScreenSize, 250);
    });
}

document.addEventListener('DOMContentLoaded', function () {
    initSwiperOnMobile();
});


const menubuttons = document.querySelector(".menu-btns-mbl");
function showBurger() {

    if (menubuttons.style.display === 'none') {
        menubuttons.style.display = 'flex'
    } else {
        menubuttons.style.display = 'none'
    }

}

const qouteswiper = new Swiper('.qoute-swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    centeredSlides: false,
    loop: false,
    clickable: true,
    slidesPerView: 1
})

const mentorswiper = new Swiper('.mentors-swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    centeredSlides: false,
    loop: true,
    clickable: true,
    slidesPerView: 1
})